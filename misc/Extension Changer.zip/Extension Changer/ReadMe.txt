Extension Changer Version 0.4 by Yehia Ahmed
-===========================================-


D_E_S_C_R_I_P_T_I_O_N
-===================-

If you ever wanted to know a file's extension or tried to change it, 
you have 2 solutions:

  1- Uncheck "Hide file extensions of known file types" option from 
     Folder Options dialog.
  2- Rename the file from DOS.

This 2 Solutions are not too easy and required a lot of time.
So, here is Extension Changer. It's the simplest way to change 
a file' extension, just Drag&Drop the file into the form, and 
enter its new extension.




I_N_S_T_A_L_L N_O_T_E_S
-=====================-

Run extchanger.exe



G_E_T S_T_A_R_T_E_D
-=================-

* The extension changer has an easy GUI,
  just drag'n drop the file you wanna change
  into it or use the shell build in function
  on the file it self.
* Once the extension changer has add the file 
  to it, insert the extension below and push 'change'.
* If a message appears with this title "Confirm 'Edit The Extension Action" when you 
  select more than one file, there is no problem just click on OK.


This file was created by Drakx Multimedia 2002