This zip-file contains the CustomContextMenu, a class for making your own
context menu handlers.

Refer to CustomContextMenu.html and OwnerDrawContextMenu.html for documentation.

***** If you redistribute this package, please include all original files. *****

