This is a demo for registering a custom context menu handler.

The CopyPath handler is used as an example.

Troels Jakobsen
delphiuser@get2net.dk

