VerInfo 1.0.0
Author: Troels Jakobsen
-----------------------

The Delphi source code makes use of interfaces to access the
Windows context menu. I could never have done that part of
the code from scratch. I used some source code developed by
Neil J. Rubenking, which I found here:
http://www.zdnet.com/pcmag/issues/1601/pcmg0034.htm
http://www.zdnet.com/pcmag/issues/1602/pcmg0030.htm

Unfortunately his original source code is no longer available
from ZDNet, but I have included it as delsh2.zip.


Comments, corrections, suggestions? I would very much like to
hear them.

Troels Jakobsen
delphiuser@get2net.dk

